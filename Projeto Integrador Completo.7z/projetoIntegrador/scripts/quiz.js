const quizzes = {
  odontologia: [
    {
      text: "Qual das atitudes abaixo ajuda a manter o equilíbrio emocional no uso das tecnologias?",
      options: [
        "Verificar as notificações assim que acorda",
        "Comparar sua vida com a dos influenciadores ",
        "Estabelecer limites de tempo para o uso do celular",
        "Passar mais tempo online para “não ficar por fora”"
      ],
      answer: 2
    },
    {
      text: "Uma das principais armadilhas da vida digital é a comparação constante com outras pessoas. Qual é o impacto mais comum disso na saúde mental dos jovens?",
      options: [
        "Sensação de pertencimento e autoconfiança",
        "Aumento da produtividade",
        "Queda na autoestima e sensação de inadequação",
        "Desenvolvimento de empatia e motivação"
      ],
      answer: 2
    },
    {
      text: "Em relação aos prós do mundo digital, podemos dizer que:",
      options: [
        "Ele sempre prejudica as relações reais",
        "Facilita o aprendizado e o acesso a informações de qualidade",
        "Isola as pessoas e as afasta da realidade ",
        "Impede o contato com novas ideias"
      ],
      answer: 1
    },
    {
      text: "Sobre o conceito de bem-estar digital, qual das alternativas representa melhor uma prática consciente e equilibrada?",
      options: [
        "Alternar entre redes sociais constantemente para se distrair",
        "Deixar as notificações sempre ativadas para não perder nada",
        "Estabelecer momentos offline e refletir sobre o impacto do uso das redes no seu humor",
        "Usar o celular como principal forma de relaxamento"
      ],
      answer: 2
    }
  ],
  pedagogia: [
    {
      text: "Como você acha que o uso excessivo das redes sociais pode influenciar a concentração e o aprendizado em sala de aula?",
      options: [
        "Melhora a concentração, pois ajuda a focar nos estudos.",
        "Não influencia em nada.",
        "Pode atrapalhar a atenção e diminuir o rendimento escolar.",
        "Facilita o aprendizado em todos os aspectos."
      ],
      answer: 2
    },
    {
      text: "Quais sinais podem indicar que um colega de classe está enfrentando problemas de saúde mental relacionados ao uso da internet?",
      options: [
        "Maior interação social e disposição em sala.",
        "Ansiedade, isolamento e queda no desempenho escolar.",
        "Aumento do interesse pelas aulas.",
        "Melhor organização com as tarefas escolares."
      ],
      answer: 1
    },
    {
      text: "Qual é a principal função da avaliação diagnóstica?",
      options: [
        "Classificar os alunos",
        "Identificar dificuldades e potencialidades",
        "Atribuir notas",
        "Premiar os melhores alunos"
      ],
      answer: 1
    },
    {
      text: "Em sua opinião, quais são os principais benefícios e os principais riscos do uso das tecnologias digitais para os jovens?",
      options: [
        "Benefícios: comunicação rápida; Riscos: dependência e isolamento.",
        "Benefícios: nenhum; Riscos: todos os possíveis.",
        "Benefícios: apenas diversão; Riscos: nenhum.",
        "Benefícios: melhora só nos jogos; Riscos: melhora nos estudos."
      ],
      answer: 0
    }
  ],
  direito: [
    {
      text: "Como o uso excessivo de redes sociais pode afetar a saúde mental de estudantes de Direito?",
      options: [
        "Melhora automática do humor",
        "Ansiedade e comparação social",
        "Mais foco nos estudos",
        "Nenhuma mudança"
      ],
      answer: 1
    },
    {
      text: "Qual é um dos principais sintomas do estresse digital?",
      options: [
        "Alegria excessiva",
        "Dores de cabeça e irritação",
        "Aumento de memória",
        "Força física"
      ],
      answer: 1
    },
    {
      text: "O que significa o termo 'dependência digital'?",
      options: [
        "Estudar muito",
        "Incapacidade de ficar desconectado",
        "Comer mais",
        "Dormir melhor"
      ],
      answer: 1
    },
    {
      text: "Como a comparação social online pode impactar a autoestima?",
      options: [
        "Aumentar autoconfiança",
        "Diminuir autoestima",
        "Melhorar memória",
        "Não causar efeito"
      ],
      answer: 1
    },
    {
      text: "Qual prática pode ajudar na saúde mental em ambientes acadêmicos virtuais?",
      options: [
        "Não conversar com ninguém",
        "Fazer pausas e organização",
        "Estudar 12h por dia",
        "Usar mais redes"
      ],
      answer: 1
    },
    {
      text: "O cyberbullying pode provocar quais consequências psicológicas?",
      options: [
        "Nenhum efeito",
        "Autoestima elevada",
        "Ansiedade e depressão",
        "Fome constante"
      ],
      answer: 2
    },
    {
      text: "O que são 'fake news' e qual impacto podem ter na saúde mental dos estudantes?",
      options: [
        "Informações reais que ajudam",
        "Notícias falsas que causam medo",
        "Exercícios físicos",
        " Jogos online educativos"
      ],
      answer: 1
    },
    {
      text: "Como o excesso de estudos online pode influenciar o sono?",
      options: [
        "Melhora do desempenho físico",
        "Insônia e cansaço",
        "Felicidade extrema",
        "Motivação constante"
      ],
      answer: 1
    },
    {
      text: "Qual atitude é recomendada para equilibrar estudos digitais e bem-estar emocional?",
      options: [
        "Nunca descansar",
        "Fazer pausas e limites de tela",
        "Estudar sem parar",
        "Se isolar socialmente"
      ],
      answer: 1
    },
    {
      text: "O uso consciente da internet contribui para:",
      options: [
        "Aumento de estresse",
        "Melhor relacionamento com a tecnologia",
        "Vício digital",
        "Sono irregular"
      ],
      answer: 1
    }
  ],
  computacao: [
    {
      text: "O uso frequente das redes sociais pode gerar sentimentos de ansiedade ou insatisfação pessoal principalmente porque:",
      options: [
        "Permite conhecer pessoas novas todos os dias.",
        "Expõe os usuários a comparações constantes com vidas idealizadas.",
        "Estimula apenas conteúdos educativos e culturais.",
        "Aumenta o contato com familiares distantes."
      ],
      answer: 1
    },
    {
      text: "Quando uma pessoa sente necessidade de checar o celular a todo momento, mesmo sem motivo claro, isso pode indicar:",
      options: [
        "Um hábito normal da vida moderna.",
        "Um possível comportamento de dependência digital.",
        "Maior capacidade de atenção e foco.",
        "Que o aparelho está com falhas técnicas."
      ],
      answer: 1
    },
    {
      text: "Por que o sono é afetado quando se usa o celular antes de dormir?",
      options: [
        "Porque a luz da tela e o estímulo constante dificultam o relaxamento.",
        "Porque o aparelho emite sons que ajudam a dormir.",
        "Porque o uso noturno melhora a concentração.",
        "Porque o corpo precisa se adaptar à tecnologia."
      ],
      answer: 0
    },
    {
      text: "Qual das atitudes abaixo demonstra um uso consciente das tecnologias?",
      options: [
        "Ler comentários negativos para entender melhor os outros.",
        "Refletir sobre o tempo gasto on-line e estabelecer limites diários.",
        "Seguir perfis que geram comparação e competição.",
        "Manter-se conectado o dia todo para não “perder nada”."
      ],
      answer: 1
    },
    {
      text: "Em tempos de excesso de informações e notícias nas redes, cuidar da saúde mental envolve:",
      options: [
        "Evitar completamente o contato com notícias.",
        "Consumir informações de forma crítica e dar pausas quando sentir sobrecarga.",
        "Acompanhar todas as atualizações em tempo real.",
        "Compartilhar tudo o que recebe para se manter ativo nas redes."
      ],
      answer: 1
    }
  ]
};

// ----- Variáveis de controle -----
let questions = [];
let current = 0;
let selected = null;
let answered = false;
let userAnswers = [];
let quizTitle = '';

function startQuiz(tipo) {
  questions = quizzes[tipo];
  quizTitle =
    tipo === 'odontologia' ? 'Quiz de Odontologia' :
    tipo === 'pedagogia' ? 'Quiz de Pedagogia' :
    tipo === 'direito' ? 'Quiz de Direito' :
    tipo === 'computacao' ? 'Quiz de Ciência da Computação' : 'Quiz';
  current = 0;
  selected = null;
  answered = false;
  userAnswers = [];
  document.getElementById('quizTitle').textContent = quizTitle;
  const startScreenEl = document.getElementById('startScreen');
  if (startScreenEl) startScreenEl.style.display = 'none';
  const quizCont = document.getElementById('quizContainer');
  if (quizCont) quizCont.style.display = '';
  // Entrar em modo de quiz: esconder header/nav/footer e mostrar apenas as questões
  try { document.body.classList.add('quiz-mode'); } catch (e) {}
  renderQuestion();
}

function renderQuestion() {
  document.getElementById('questionNumber').textContent =
    `Pergunta ${current + 1} de ${questions.length}`;
  document.getElementById('questionText').textContent =
    questions[current].text;

  const optionsList = document.getElementById('optionsList');
  optionsList.innerHTML = '';
  document.getElementById('feedback').textContent = '';

  // animação: reinicia a classe para acionamento de entrada
  const qEl = document.getElementById('questionText');
  if (qEl) {
    qEl.classList.remove('animate-in');
  }
  if (optionsList) {
    optionsList.classList.remove('animate-in');
  }

  questions[current].options.forEach((option, idx) => {
    const btn = document.createElement('button');
    btn.className = 'option-btn' + (selected === idx ? ' selected' : '');
    btn.textContent = option;
    btn.disabled = answered;

    if (answered && selected === idx) {
      if (selected === questions[current].answer) {
        btn.classList.add('correct');
      } else {
        btn.classList.add('incorrect');
      }
    }
    btn.onclick = () => {
      selected = idx;
      document.getElementById('checkBtn').disabled = false;
      renderQuestion();
    };
    optionsList.appendChild(btn);
  });

  // forçar reflow e reaplicar animação
  if (qEl) {
    void qEl.offsetWidth;
    qEl.classList.add('animate-in');
  }
  if (optionsList) {
    void optionsList.offsetWidth;
    optionsList.classList.add('animate-in');
  }

  document.getElementById('checkBtn').disabled = selected === null || answered;
  document.getElementById('nextBtn').disabled = !answered;
  document.getElementById('backBtn').disabled = current === 0;
}

function showFeedback() {
  const feedback = document.getElementById('feedback');
  if (selected === questions[current].answer) {
    feedback.textContent = "Você acertou!";
    feedback.style.color = "#4caf50";
  } else {
    feedback.textContent = "Você errou!";
    feedback.style.color = "#f44336";
  }
}

document.getElementById('checkBtn').onclick = () => {
  if (selected !== null && !answered) {
    answered = true;
    userAnswers[current] = selected;
    showFeedback();
    renderQuestion();
  }
};

document.getElementById('nextBtn').onclick = () => {
  selected = null;
  answered = false;
  document.getElementById('feedback').textContent = '';
  current++;
  if (current < questions.length) {
    renderQuestion();
  } else {
    showReport();
  }
};

document.getElementById('backBtn').onclick = () => {
  if (current > 0) {
    current--;
    selected = userAnswers[current] !== undefined ? userAnswers[current] : null;
    answered = userAnswers[current] !== undefined;
    document.getElementById('feedback').textContent = '';
    renderQuestion();
  }
};

function showReport() {
  let correct = questions.filter((q, i) => userAnswers[i] === q.answer).length;
  let incorrect = questions.length - correct;
  let html = `<h2 class="quiz-title">Quiz finalizado</h2>`;
  html += `<div class="report-summary" style="text-align:center;font-size:1.05em;margin-bottom:18px;">
    Acertos: <span style="color:#4caf50;font-weight:bold;">${correct}</span> / ${questions.length}
  </div>`;

  html += `<ul class="report-list" style="list-style:none;padding:0;margin:0;">`;
  questions.forEach((q, idx) => {
    const user = userAnswers[idx];
    const isCorrect = user === q.answer;
    const userText = (user === undefined) ? '<em>Sem resposta</em>' : q.options[user];
    const correctText = q.options[q.answer];
    html += `<li class="report-item ${isCorrect ? 'correct' : 'incorrect'}">
      <div class="report-q"><span class="num">${idx + 1}.</span> <span class="qtext">${q.text}</span></div>
      <div class="report-answers">
        <div class="answer-user">Sua resposta: <span class="ans">${userText}</span></div>
        <div class="answer-correct">Resposta certa: <span class="ans">${correctText}</span></div>
      </div>
    </li>`;
  });
  html += `</ul>`;

  html += `
    <div style="display:flex;justify-content:center;margin-top:28px;">
      <button id="backToStartBtn" class="final-btn">Voltar à seleção de quiz</button>
    </div>
  `;

  document.querySelector('.quiz-container').innerHTML = html;

  const canvas = document.getElementById('resultChart');
  if (canvas && canvas.getContext) {
    const ctx = canvas.getContext('2d');
    const total = correct + incorrect;
    const angleCorrect = (correct / total) * 2 * Math.PI;

    ctx.beginPath();
    ctx.arc(70, 70, 65, 0, 2 * Math.PI);
    ctx.closePath();
    ctx.fillStyle = "#23272f";
    ctx.fill();

    const gradGreen = ctx.createLinearGradient(0, 0, 140, 140);
    gradGreen.addColorStop(0, "#43cea2");
    gradGreen.addColorStop(1, "#4caf50");
    ctx.beginPath();
    ctx.moveTo(70, 70);
    ctx.arc(70, 70, 60, -Math.PI/2, -Math.PI/2 + angleCorrect, false);
    ctx.closePath();
    ctx.fillStyle = gradGreen;
    ctx.shadowColor = "#4caf50";
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.shadowBlur = 0;

    if (incorrect > 0) {
      const gradRed = ctx.createLinearGradient(0, 0, 140, 140);
      gradRed.addColorStop(0, "#f44336");
      gradRed.addColorStop(1, "#ff1744");
      ctx.beginPath();
      ctx.moveTo(70, 70);
      ctx.arc(70, 70, 60, -Math.PI/2 + angleCorrect, -Math.PI/2 + 2 * Math.PI, false);
      ctx.closePath();
      ctx.fillStyle = gradRed;
      ctx.shadowColor = "#f44336";
      ctx.shadowBlur = 12;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    ctx.beginPath();
    ctx.arc(70, 70, 60, 0, 2 * Math.PI);
    ctx.lineWidth = 4;
    ctx.strokeStyle = "#fff";
    ctx.stroke();
  }

  const backBtn = document.getElementById('backToStartBtn');
  if (backBtn) {
    backBtn.onclick = () => {
      const quizCont = document.getElementById('quizContainer');
      if (quizCont) quizCont.style.display = 'none';
      const startEl = document.getElementById('startScreen');
      if (startEl) startEl.style.display = 'flex';
      try { document.body.classList.remove('quiz-mode'); } catch (e) {}
    };
  }
}

window.onload = renderQuestion;

document.addEventListener('DOMContentLoaded', function() {
  const btn = document.getElementById('backToStartBtnQuiz');
  if (btn) {
    btn.onclick = () => {
      const quizCont = document.getElementById('quizContainer');
      if (quizCont) quizCont.style.display = 'none';
      const startEl = document.getElementById('startScreen');
      if (startEl) startEl.style.display = 'flex';
      try { document.body.classList.remove('quiz-mode'); } catch (e) {}
    };
  }
  const exitBtn = document.getElementById('exitQuizBtn');
  if (exitBtn) {
    exitBtn.onclick = () => {
      const quizCont = document.getElementById('quizContainer');
      if (quizCont) quizCont.style.display = 'none';
      const startEl = document.getElementById('startScreen');
      if (startEl) startEl.style.display = 'flex';
      try { document.body.classList.remove('quiz-mode'); } catch (e) {}
    };
  }
});
